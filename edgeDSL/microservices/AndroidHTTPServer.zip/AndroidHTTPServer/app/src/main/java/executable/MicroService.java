package executable;

import java.util.Map;

/**
 * Created by LocalAdministrator on 10/11/2017.
 */
public interface MicroService {
    public String execute(Map<String, String> params);
}
