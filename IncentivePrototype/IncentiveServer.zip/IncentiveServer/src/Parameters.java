class Parameters {

    static int MAX_PHASE = 5;
    static int MAX_ROUTER = 1;
    static int SLEEP = 5000;
    static double BUDGET = 1024;
    static double THRESHOLD = 5;

}
